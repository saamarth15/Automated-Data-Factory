<?php
header("location:login_portal.php");
?>