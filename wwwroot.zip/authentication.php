<!--user authentication-->
<?php
    $server = 'abdpl-l2.database.windows.net';
    $user = 'abdadmin';
    $pass = 'abdpl@ho13';
    //Define Port
    $port='Port=1433';
    $database = 'ABDPL';

    $connection_string = "DRIVER={ODBC Driver 13 for SQL Server};SERVER=$server;$port;DATABASE=$database";

    $con = odbc_connect($connection_string,$user,$pass) or die(odbc_error($con));
    if(isset($_POST['username']))
    {
    session_start();
    $username = $_POST['username'];
    $passcode1 = $_POST['password'];
    $username= trim($username);
    $select_query = "select PASSWORD1 from login_creds where USERNAME = '$username'";
    $select_query_result = odbc_exec($con, $select_query) or die(odbc_error($con));
    $row = odbc_fetch_array($select_query_result);
    
    if ($row['PASSWORD1'] == "$passcode1" )
    {
       $_SESSION['username'] ="$username";
       header("location:display_portal.php");}
    else{
        unset($_SESSION['username']);
       header("location:login_portal.php");
    }
    }
    else{
        header("location:login_portal.php");
    }

?>