#Import Library
#Import other necessary libraries like pandas, numpy...
from statsmodels.tsa.arima_model import ARIMA
from statsmodels.tsa.stattools import acf, pacf
import pandas as pd
import pyodbc
import os
import sys
import datetime
import numpy as np
import json
server = 'abdpl-l2.database.windows.net'
database = 'ABDPL'
username = 'abdadmin'
password = 'abdpl@ho13'
driver= '{ODBC Driver 13 for SQL Server}'
db = pyodbc.connect('DRIVER='+driver+';PORT=1433;SERVER='+server+';PORT=1443;DATABASE='+database+';UID='+username+';PWD='+ password)
#Load Train and Test datasets
variable = "CASES"
#date='DATE'
state = sys.argv[1]
date = sys.argv[2]
qty = sys.argv[3]
month =sys.argv[4]
brand = sys.argv[5]
year = sys.argv[6]
range_var = sys.argv[7]
n=1
if(state=='KARNATAKA1'):
    n=2
current = datetime.datetime.today() - datetime.timedelta(days=n)
current_month = current.strftime("%m")
current_year = current.strftime("%Y")
if(month==current_month and year==current_year):
    df = pd.read_sql_query("SELECT SUM(cast("+qty+" as float)) as "+variable+","+date+" from "+state+" where ("+brand+"  like '%STERLING%' or "+brand+"  like '%OFFICERS CHOICE%' or "+brand+"  like 'OFFICER_S CHOICE%') and "+brand+"  like '%WHISKY%' group by "+date+" order by convert(date,"+date+",103)",db)
    #df = pd.read_sql_query("SELECT SUM(cast(case1 as int)) as "+variable+","+date+" from JHARKHAND where (label_name  like '%STERLING%' or label_name  like '%OFFICERS CHOICE%' or label_name  like 'OFFICER_S CHOICE%') and label_name like '%WHISKY%' group by date order by convert(date,date,103)",db)
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)
    df[date] = pd.to_datetime(df[date])
    ts=df['CASES']
    #print ts
    ts_log=np.log(ts)
    model=ARIMA(ts_log,order=(1,1,1))
    results_arima = model.fit(disp=0)
    print results_arima.summary()
    predictions=results_arima.predict(len(ts)-3,len(ts)+3,typ='levels')
    predictions_arima=np.exp(predictions)
    #print predictions_arima
    pred = {}
    count=0
    for i in predictions_arima.index:
        pred[count]=predictions_arima[i]
        count=count+1
    print json.dumps(pred)