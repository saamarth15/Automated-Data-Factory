<!--creation of login form-->
<html>
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="HandheldFriendly" content="true">
        <title>Login Portal</title>
        <link href="https://fonts.googleapis.com/css?family=Jura" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            /* Tablet Landscape */
            @media screen and (max-width: 1060px) {
                #primary { width:67%; }
                #secondary { width:30%; margin-left:3%;}  
            }
            /* Tabled Portrait */
            @media screen and (max-width: 768px) {
                #primary { width:100%; }
                #secondary { width:100%; margin:0; border:none; }
            }
            .image{
            background-image :url("abd1.jpg");
            -webkit-background-size: cover;
            -moz-background-size: cover;
            -o-background-size: cover;
            background-repeat:no-repeat;
            font-family: 'Jura', sans-serif;
                }
            .top_margin{
                margin-top:90px;   
            }
        </style>
    </head>
</head>
<body class="image">
   <div class="container">
        <div class="row top_margin">
            <div class="col-xs-8 col-xs-offset-2">
                <div class="panel panel-danger" style="background-color:rgb(61, 64, 68)">
                    <div class="panel-heading" style="color:black"><center><h3>ABD Login Portal</h3></center></div>
                    <div class="panel-body">
                        <form method="POST" action="authentication.php">                        
                           <div class="form-group">
                                <label for="username" style="color:white">Username</label>
                                <input type="text" class="form-control" placeholder="User Name" autocomplete="off" id="username" name="username" required="true">
                            </div>
                            <div class="form-group">
                                <label for="password" style="color:white">Password</label>
                                <input type="password" class="form-control" placeholder="password" id="password" name="password" required="true" >
                            </div>
                            <button type="submit" class="btn btn-primary" value="registration_submit">Submit</button>
                        </form>
                    </div>
                </div>
    </div>
</body>