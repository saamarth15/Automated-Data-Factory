<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<style>
/* Tablet Landscape */
@media screen and (max-width: 1060px) {
    #primary { width:67%; }
    #secondary { width:30%; margin-left:3%;}  
}
/* Tabled Portrait */
@media screen and (max-width: 768px) {
    #primary { width:100%; }
    #secondary { width:100%; margin:0; border:none; }
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
.hidden{
    display:none;
}
.unhidden{
    display:block;
}
</style>

<script type="text/javascript">
function unhide(clickedButton,DivId) {
  window.onload = function(){
  var item = document.getElementById('link');
if (item) {
    if(item.className == "hidden"){
        item.className = "unhidden";
    }
}
}
}
</script>
<!--plotly.js script to include graph libraries-->
<script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
</head>
<title>Display Portal</title>
<body>
<div><center>
<p><b><h2>Analysis Report</h2></b></p>
<form action = "" method = "post">
<select name="state">
  <option value="default" disabled selected>--select state--</option>
  <option value="KARNATAKA1|DATE|NO_OF_BOTTLES|ITEMNAME|KARNATAKA">Karnataka</option>
  <option value="JHARKHAND|DATE|CASE1|LABEL_NAME|JHARKHAND" >Jharkhand</option>
  <option value="WB1|DATE|tot_cases|PRODUCT|WEST BENGAL">West Bengal</option>
</select>
<select name="month">
  <option value="default" disabled selected>--select month--</option>
  <option value="%|4" >ALL</option>
  <option value="02|1" >Feb</option>
  <option value="03|1">Mar</option>
  <option value="04|1">Apr</option>
  <option value="05|1">May</option>
  <option value="06|1">Jun</option>
  <option value="07|1">Jul</option>
  <option value="08|1">Aug</option>
  <option value="09|1">Sep</option>
  <option value="10|1">Oct</option>
  <option value="11|1">Nov</option>
  <option value="12|1">Dec</option>
</select>
<select name="year">
  <option value="default" disabled selected>--select year--</option>
  <option value="2019">2019</option>
  <option value="2020">2020</option>
  <option value="2021">2021</option>
  <option value="2022">2022</option>
  <option value="2023">2023</option>
  <option value="2024">2024</option>
  <option value="2025">2025</option>
  <option value="2026">2026</option>
  <option value="2027">2027</option>
  <option value="2028">2028</option>
  <option value="2029">2029</option>
</select>
<input type = "submit" value = "submit" onclick="unhide(this,'link')"/>
</form>
</center></div>
<br>
<?php
#check if direct access is present or else return to login page
if(!isset($_SERVER['HTTP_REFERER'])){
    // redirect them to your desired location
    header('location:login_portal.php');
    exit;
}
session_start();
#check if username was set during login for current session established or else return to login page
if(isset($_SESSION['username']))
{
    $val=0;
#check if all parameters are selected
if(isset($_POST['state'])&&isset($_POST['month'])&&isset($_POST['year']))
{
$result_explode = explode('|', $_POST['state']);
$selectOption1 = $result_explode[0];
$selectOption2 = $result_explode[1];
$selectOption3 = $result_explode[2];
$result_explode1 = explode('|', $_POST['month']);
$selectOption4 = $result_explode1[0];
$selectOption7 = $result_explode1[1];
$selectOption5 = $result_explode[3];
$selectOption6 = $_POST['year'];
$selectOption8 = $result_explode[4];
echo "<center><b>".$selectOption8." ".$selectOption6."</b></center>";
$server = 'abdpl-l2.database.windows.net';
$user = 'abdadmin';
$pass = 'abdpl@ho13';
//Define Port
$port='Port=1433';
$database = 'ABDPL';
#connection string
$connection_string = "DRIVER={ODBC Driver 13 for SQL Server};SERVER=$server;$port;DATABASE=$database;Connection Timeout=0";
$con = odbc_connect($connection_string,$user,$pass,SQL_CUR_USE_ODBC) or die(odbc_error($con));
$total = 'total';
#sql queries
$sql="SELECT SUM(cast($selectOption3 as float)) as $total,substring($selectOption2,$selectOption7,10) as $selectOption2 from $selectOption1 where (($selectOption5 not like '%STERLING%' and $selectOption5 not like '%OFFICERS CHOICE%' and $selectOption5 not like 'OFFICER_S CHOICE%') and $selectOption5 like '%WHISKY%') and $selectOption2 like '%/$selectOption4/$selectOption6' group by substring($selectOption2,$selectOption7,10) order by $selectOption2";
$sql2="SELECT SUM(cast($selectOption3 as float)) as $total,substring($selectOption2,$selectOption7,10) as $selectOption2 from $selectOption1 where (($selectOption5  like 'STERLING%' or $selectOption5 like 'OFFICER_S CHOICE%' or $selectOption5 like 'OFFICERS CHOICE%') and $selectOption5 like '%WHISKY%') and $selectOption2 like '%/$selectOption4/$selectOption6' group by substring($selectOption2,$selectOption7,10) order by $selectOption2";
$sql3="SELECT SUM(cast($selectOption3 as float)) as $total,substring($selectOption2,$selectOption7,10) as $selectOption2 from $selectOption1 where $selectOption5 like '%WHISKY%' and $selectOption2 like '%/$selectOption4/$selectOption6' group by substring($selectOption2,$selectOption7,10) order by $selectOption2";
$sql4="select $selectOption5,SUM(cast($selectOption3 as float)) as $total from $selectOption1 where $selectOption2 like '%/$selectOption4/$selectOption6' and $selectOption5 like '%whisky%' and ($selectOption5  like 'STERLING%' or $selectOption5 like 'OFFICER_S CHOICE%' or $selectOption5 like 'OFFICERS CHOICE%') group by $selectOption5";
$output_graph = json_decode(exec("D:\home\Python27\python data_science.py $selectOption1 $selectOption2 $selectOption3 $selectOption4 $selectOption5 $selectOption6 $selectOption7"),true);
$output_graph2 = json_decode(exec("D:\home\Python27\python data_science2.py $selectOption1 $selectOption2 $selectOption3 $selectOption4 $selectOption5 $selectOption6 $selectOption7"),true);
date_default_timezone_set('Asia/Kolkata');
if($selectOption1 !='KARNATAKA1')
{
$date5=date('d/m/Y');
$date6=date('d/m/Y',strtotime("+1 days"));
$date7=date('d/m/Y',strtotime("+2 days"));
}
else{
$date5=date('d/m/Y',strtotime("-1 days"));
$date6=date('d/m/Y');
$date7=date('d/m/Y',strtotime("+1 days"));
}
# Execute the statement for graphical view
$rs1 =odbc_exec($con,$sql2);
while(odbc_fetch_row($rs1)){
$col1[] = odbc_result($rs1,$selectOption2);
$col2[] = odbc_result($rs1,$total);
}
$rs =odbc_exec($con,$sql);
while(odbc_fetch_row($rs)){
$col3[] = odbc_result($rs,$selectOption2);
$col4[] = odbc_result($rs,$total);
}
$rs3 =odbc_exec($con,$sql3);
while(odbc_fetch_row($rs3)){
$col5[] = odbc_result($rs3,$selectOption2);
$col6[] = odbc_result($rs3,$total);
}
$rs4 =odbc_exec($con,$sql4);
while(odbc_fetch_row($rs4)){
$col7[] = odbc_result($rs4,$selectOption5);
$col8[] = odbc_result($rs4,$total);
$val=1;
}
$dates= array($col1[sizeof($col1)-4],$col1[sizeof($col1)-3],$col1[sizeof($col1)-2],$col1[sizeof($col1)-1],$date5,$date6,$date7);
if($val==0)
{
  echo "<br>";
  echo "<center>no data found!</center>";
}
// Disconnect the database from the database handle.
odbc_close($con);
}
else{ $val=0;}
}
else{
  header("location:login_portal.php");
}
?>
<!--display plots created by plotly in below divs-->
<br>
<div id="myDiv1" ><!-- Plotly chart will be drawn inside this DIV --></div>
<br>
<br>
<div id="myDiv2"><!-- Plotly chart will be drawn inside this DIV --></div>
<br>
<br>
<div id="myDiv3"><!-- Plotly chart will be drawn inside this DIV --></div>
<br>
<br>
<div id="myDiv4"><!-- Plotly chart will be drawn inside this DIV --></div>
<br> 
<br>
<div id="myDiv5" ><!-- Plotly chart will be drawn inside this DIV --></div>
<br>
<br>
<div id="myDiv6" ><!-- Plotly chart will be drawn inside this DIV --></div>
<br>
<div>
<center><b><a href="login_portal.php">Logout</a></b></center>
</div>
<!--plotly.js script to create graph-->
<script>
var val='<?php echo $val; ?>';
var val1='<?php echo json_encode($output_graph); ?>';
var val2='<?php echo json_encode($output_graph2); ?>';
    var data = 
  {
    x: <?php echo json_encode($col1); ?>,
    y: <?php echo json_encode($col2); ?>,
    name:'ABD brand sales',
    type: 'bar'
  };
    var data0 = 
  {
    x: <?php echo json_encode($col3); ?>,
    y: <?php echo json_encode($col4); ?>,
    name:'competitive brand sales',
    type: 'bar'
  };
  var data3 = [data,data0];
   var data1 = [
  {
    x: <?php echo json_encode($col1); ?>,
    y: <?php echo json_encode($col2); ?>,
    name:'actual market status of ABD',
    type: 'linear'
  }];
  var data2 =[
  { 
    x: <?php echo json_encode($dates); ?>,  
    y: <?php echo json_encode($output_graph); ?>,
    name:'predicted market status of ABD',
    mode: 'lines',
  line: {
    color: 'rgb(255, 165, 0)',
    width: 3
  }
  }];
    var data4 =[
  {
    x: <?php echo json_encode($col5); ?>,
    y: <?php echo json_encode($col6); ?>,
    name:'actual market status of whisky',
    type: 'linear'
  }];
  var data5  =[
  {
    x: <?php echo json_encode($dates); ?>,  
    y: <?php echo json_encode($output_graph2); ?>,
    name:'predicted market status of whisky',
     mode: 'lines',
  line: {
    color: 'rgb(255, 165, 0)',
    width: 3
  }
  }];
      var data6 =[ 
  {
    x: <?php echo json_encode($col7); ?>,
    y: <?php echo json_encode($col8); ?>,
    type: 'bar'
  }];
var layout2 = {
  autosize: true,
  title: {
    text:'<b>ABD Brands Growth Graph</b>',
  },
  xaxis: {
    title: {
      text: 'days',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    },
  },
  yaxis: {
    title: {
      text: 'cases',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    }
  }
};
var layout3 = {
  autosize: true,
  title: {
    text:'<b>Whisky brands Growth Graph</b>',
  },
  xaxis: {
    title: {
      text: 'days',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    },
  },
  yaxis: {
    title: {
      text: 'cases',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    }
  }
};
var layout4 = {
  autosize: true,
  title: {
    text:'<b>ABD Brands Status</b>',
  },
  xaxis: {
    title: {
      text: 'ABD brands',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    },
  },
  yaxis: {
    title: {
      text: 'cases',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    }
  }
};
var layout5 = {
    autosize: true,
    title: {
    text:'prediction for three days ahead',
  },
  xaxis: {
    title: {
      text: 'days',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    },
  },
  yaxis: {
    title: {
      text: 'cases',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    }
  }
};
var layout1 = {
    autosize: true,
    barmode: 'stack',
    title: {
    text:'<b>Competitor Brands VS ABD Brands</b>',
  },
  xaxis: {
    title: {
      text: 'days',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    },
  },
  yaxis: {
    title: {
      text: 'cases',
      font: {
        family: 'Courier New, monospace',
        size: 18
      }
    }
  }
};
 if(val=='1'){
Plotly.newPlot('myDiv1', data3,layout1,{responsive:true});
Plotly.newPlot('myDiv2', data1,layout2,{responsive:true});
if(val1 != 'null')
Plotly.newPlot('myDiv3', data2,layout5,{responsive:true});
Plotly.newPlot('myDiv4', data4,layout3,{responsive:true});
if(val2 != 'null')
Plotly.newPlot('myDiv5', data5,layout5,{responsive:true});
Plotly.newPlot('myDiv6', data6,layout4,{responsive:true});
}
</script>
<br>
<br>
</body>
</html>